create function sp_sw_get_longest_opening_crawl_movie()
    returns TABLE(id integer, name character varying, no_of_characters bigint, len integer)
    language plpgsql
as
$$
BEGIN
  RETURN QUERY
  SELECT 
    fm.id, 
    fm.title AS name, 
    COUNT(DISTINCT people_id) AS no_of_characters, 
    LENGTH(TRIM(opening_crawl)) AS len 
  FROM star_wars.films fm
  LEFT JOIN star_wars.films_characters fc ON fm.id = fc.film_id
  GROUP BY fm.id 
  ORDER BY len DESC 
  LIMIT 1;
END;
$$;

alter function sp_sw_get_longest_opening_crawl_movie() owner to alumno;

