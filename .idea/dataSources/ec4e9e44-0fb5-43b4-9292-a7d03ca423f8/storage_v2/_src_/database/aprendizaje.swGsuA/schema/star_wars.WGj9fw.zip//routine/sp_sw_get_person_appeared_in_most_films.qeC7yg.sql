create function sp_sw_get_person_appeared_in_most_films()
    returns TABLE(id integer, name character varying, no_of_film bigint)
    language plpgsql
as
$$
BEGIN
  RETURN QUERY
  SELECT 
    pp.id, 
    pp.name, 
    COUNT(DISTINCT fc.film_id) AS no_of_film 
  FROM star_wars.people pp 
  LEFT JOIN star_wars.films_characters fc ON pp.id = fc.people_id
  GROUP BY pp.id 
  HAVING COUNT(DISTINCT fc.film_id) = 6 
  ORDER BY no_of_film DESC, pp.id;
END;
$$;

alter function sp_sw_get_person_appeared_in_most_films() owner to alumno;

