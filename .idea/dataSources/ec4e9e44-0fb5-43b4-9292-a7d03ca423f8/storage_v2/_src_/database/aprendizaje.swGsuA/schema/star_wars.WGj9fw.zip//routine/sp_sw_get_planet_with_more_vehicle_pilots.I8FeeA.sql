create function sp_sw_get_planet_with_more_vehicle_pilots()
    returns TABLE(id integer, name character varying, no_of_pilots bigint, pilots text)
    language plpgsql
as
$$
BEGIN
  RETURN QUERY
  SELECT 
    pt.id, 
    pt.name, 
    COUNT(*) AS no_of_pilots, 
    STRING_AGG(vpd.fulldesc, ', ') AS pilots
  FROM star_wars.planets pt
  LEFT JOIN (
    SELECT 
      pp.id, 
      pp.name, 
      CONCAT(pp.name, ' - ', COALESCE(sp.name, 'n/a')) AS fulldesc, 
      pp.homeworld_id AS homeworld, 
      COALESCE(sp.name, 'n/a') AS species 
    FROM star_wars.people pp
    INNER JOIN star_wars.vehicles_pilots vp ON pp.id = vp.people_id
    LEFT JOIN star_wars.species sp ON sp.homeworld = pp.homeworld_id
    GROUP BY pp.id, pp.homeworld_id, pp.name, sp.name
  ) vpd ON pt.id = vpd.homeworld 
  GROUP BY pt.id, pt.name
  ORDER BY no_of_pilots DESC 
  LIMIT 1;
END;
$$;

alter function sp_sw_get_planet_with_more_vehicle_pilots() owner to alumno;

