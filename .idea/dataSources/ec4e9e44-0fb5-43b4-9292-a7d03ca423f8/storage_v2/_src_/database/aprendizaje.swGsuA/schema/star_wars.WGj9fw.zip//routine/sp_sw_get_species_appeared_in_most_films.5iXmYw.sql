create function sp_sw_get_species_appeared_in_most_films()
    returns TABLE(id integer, name character varying, no_of_characters bigint, no_of_film bigint)
    language plpgsql
as
$$
BEGIN
  RETURN QUERY
  SELECT 
    sp.id, 
    sp.name, 
    COUNT(people_id) AS no_of_characters, 
    COUNT(DISTINCT fc.film_id) AS no_of_film
  FROM star_wars.species sp
  INNER JOIN star_wars.films_species fs ON sp.id = fs.species_id
  LEFT JOIN star_wars.films_characters fc ON fs.film_id = fc.film_id
  GROUP BY sp.id 
  HAVING COUNT(DISTINCT fc.film_id) = 6 
  ORDER BY no_of_characters DESC;
END;
$$;

alter function sp_sw_get_species_appeared_in_most_films() owner to alumno;

