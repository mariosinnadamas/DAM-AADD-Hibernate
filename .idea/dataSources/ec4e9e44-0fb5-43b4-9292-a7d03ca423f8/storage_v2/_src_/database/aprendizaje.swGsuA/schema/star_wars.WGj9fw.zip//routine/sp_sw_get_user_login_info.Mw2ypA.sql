create function sp_sw_get_user_login_info(p_usr character varying, p_pwd character varying)
    returns TABLE(user_data json)
    language plpgsql
as
$$
BEGIN
  -- Nota: Esta función requiere que exista una tabla 'user'
  -- Si no existe, deberás crearla primero
  RETURN QUERY
  SELECT row_to_json(u.*) 
  FROM star_wars.user u
  WHERE (u.usr_name = p_usr OR u.usr_email = p_usr) 
    AND u.usr_pwd = p_pwd 
    AND u.usr_status = 1;
END;
$$;

alter function sp_sw_get_user_login_info(varchar, varchar) owner to alumno;

